# ========================================================================================================
# Purpose:      Linear Reg on HDB Resale Flat Prices 2019.
# Author:       Neumann Chew C.H.
# DOC:          17-02-2020
# Topics:       Linear Reg, Effect of categorical X variable.
# Data:         resale-flat-prices-2019.csv from Housing & Dev Board.
#=========================================================================================================

library(data.table)
library(car)         # vif()


setwd("C:/NC/BC2407/S2 Review of Basic Analytics and Software")

data1 <- fread("resale-flat-prices-2019.csv", stringsAsFactors = T)

summary(data1)

# Compute remaining_lease_years and remove two columns ------------------------
data1$remaining_lease_years = 99 - (2019 - data1$lease_commence_date)
data1$lease_commence_date <- NULL
data1$remaining_lease <- NULL


# Change the Baseline Reference level for Town to Yishun instead of default.
levels(data1$town)  # Ang Mo Kio is the default baseline by alphabetical order.
data1$town <- relevel(data1$town, ref = "YISHUN")
levels(data1$town)   # Verifies "YISHUN" is now first factor i.e. baseline ref.


m1 <- lm(resale_price ~ floor_area_sqm + remaining_lease_years + town + 
           storey_range, data=data1)

summary(m1)

vif(m1)

summary(m1)$r.squared
summary(m1)$adj.r.squared
RMSE.m1 <- sqrt(mean(residuals(m1)^2))
RMSE.m1
