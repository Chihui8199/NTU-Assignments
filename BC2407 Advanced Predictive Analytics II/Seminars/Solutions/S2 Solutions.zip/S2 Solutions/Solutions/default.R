# ========================================================================================================
# Purpose:      Review of Binary Logistic Regression model and CART
# Author:       Neumann Chew
# DOC:          25-09-2017 for logistic Reg; 13-01-2021 for CART.
# Topics:       Logistic Regression; CART; Puning.
# Data Source:  Fictional
# Packages:     data.table, caTools
#=========================================================================================================
library(data.table)

setwd("C:/NC/BC2407/S2 Review of Basic Analytics and Software")

default.dt <- fread("default.csv", stringsAsFactors = T)

summary(default.dt)
cor(default.dt$AvgBal, default.dt$Income)

levels(default.dt$Default) # Baseline is Default = "No"

m1 <- glm(Default ~ . , family = binomial, data = default.dt)

summary(m1)
## Income is not sig in the presence of Avg balance and gender.
## To remove Income


m2 <- glm(Default ~ . -Income, family = binomial, data = default.dt)
summary(m2)


# Output the probability from the logistic function for all cases in the data.
prob <- predict(m2, type = 'response')

# If Threshold = 0.5 ---------------------------------------------
threshold1 <- 0.5
       
m2.predict <- ifelse(prob > threshold1, "Yes", "No")
                 
table1 <- table(Actual = default.dt$Default, m2.predict, deparse.level = 2)
table1
round(prop.table(table1),3)

# Overall Accuracy
mean(m2.predict == default.dt$Default)
#-------------------------------------------------------------------

# Cases whose logistic model P(Default = Yes) > 0.9
default.dt[prob > 0.9]
which(array(prob) > 0.9)



# Activity 3: CART ----------------------------------------------------
library(rpart)
library(rpart.plot)

set.seed(2021)
cart.max <- rpart(Default ~ ., data = default.dt, method = 'class',
                  control = rpart.control(minsplit = 2, cp = 0))

printcp(cart.max)
plotcp(cart.max)
## 3rd tree is optimal based pn 1SE rule.

cp.opt <- 0.04

cart.opt <- prune(cart.max, cp = cp.opt)
printcp(cart.opt)
## Num of decision rules = num of terminal nodes = 2 + 1 = 3.

cart.prob <- predict(cart.opt)

cart.yhat <- predict(cart.opt, type = "class")

cart.cm <- table(default.dt$Default, cart.yhat, deparse.level = 2)
cart.cm
# Overall Accuracy
mean(cart.yhat == default.dt$Default)

sum(cart.prob[,2] > 0.9)
# No cases in optimal CART have probability of default > 90%.
max(cart.prob[,2])
rpart.plot(cart.opt)

# Maximal CART model with 403 splits has P(default = Yes) > 90%
max(predict(cart.max)[,2])
sum(predict(cart.max)[,2] > 0.9)

# Cases whose maximal CART model P(Default = Yes) > 0.9
highrisk.cart.max <- default.dt[predict(cart.max)[,2] > 0.9]
summary(default.dt$Default)
## The maximal CART merely selects all those cases with default = yes as highrisk cases.
